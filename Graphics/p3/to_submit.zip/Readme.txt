Menu: right click on the interface
1)  change Ka
2)  change Kd
3)  change Ka
4)  change IA
5)  change IL
6)  change K
7)  change n
7)  change F

8)  Projection onto XY plane(default)
9)  Projection onto XZ plane
10) Projection onto YZ plane
11) Quit

Terminal:
1) Takes user inputs for the chosen operations (from menu)

Note:
The program assumes all inputs are in valid format.