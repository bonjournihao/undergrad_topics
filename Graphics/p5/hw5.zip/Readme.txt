---There are 2 spheres in the sphere. Their center locations are at (0,0,0) and (1,1,1), each with a radius of 0.5 and 0.2. 
---The intersections are found using the parametrized ray vector and the formula x^2+y^2+z^2 = R^2.
---The initial parameters are show after right clicking on the GUI and select "change parameters".
---The initialization of parameters are at 167-182. Most of the changings can be mad after initialization (colors parameters, ff, X). Some changes cannot be done through updating(N and angle, so I took screen shots of different results by manually changing the initializations). 
---The initializations are from lines 167 to 182. The initialization of N is on line 115.
---Didn't use external libraries.

Menu:
--Current--
1) Light position -----X : (2,2,2)
2) Light ambient ----- La: (0.5,0.5,0.5)
3) Light intensity ----- Li: (0.7,0.7,0.7)
4) Material(Object) 0 ----- Ka: (0.3,0.1,0) Kd: (0.2,0.4,0.1) Ks: (0.1,0.8,0.3) n: 5
5) Material(Object) 1 ----- Ka: (0,0.05,0) Kd: (0.4,0.4,0.4) Ks: (0.9,0.9,0.9) n: 20
6) From point ----- ff: (0,0,10)
7) Up vector ----- up: (0,1,0)
8) At point ----- at: (0,0,0)
9) Viewing angle ----- alpha: 0.4
10) Resolution ------ N: 300

